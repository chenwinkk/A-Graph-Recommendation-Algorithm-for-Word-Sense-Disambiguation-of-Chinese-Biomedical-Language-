const express = require('express')
const router = express.Router()
const sp = require('../controller/sendInfoTopython')

router.get('/first', function (req, res, next) {
  const param = JSON.stringify(req.query.value)
  sp.sendToPython(param, (_res) => {
    const result = JSON.parse(_res)
    console.log('python的print传递过来的数据', result)
    if (result.code === 0) {
      res.send(result)
    } else {
      res.send({ error: '数据错误' })
    }
  })
})
module.exports = router
