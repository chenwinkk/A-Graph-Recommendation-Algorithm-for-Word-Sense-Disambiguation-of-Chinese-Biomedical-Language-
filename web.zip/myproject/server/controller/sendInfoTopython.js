const path = require('path')
const { spawn } = require('child_process')

const sp = {
  sendToPython (params = null, callback = null) { // params是数组参数，如["参数1","参数2"]
    const url = path.resolve(__dirname, 'D:/pythonProject6/code/CHIP-CDN-Standarlization.py')
    const mySpwan = spawn('python', [url, params])
    mySpwan.stdout.on('data', (data) => {
      console.log(`data:${data}`)
      callback && callback(data.toString())
    })
    mySpwan.stderr.on('data', (data) => {
      console.log(`error:${data}`)
      callback && callback(data.toString())
    })
    mySpwan.on('close', (code) => {
      console.log('子进程已退出，退出码 ' + code)
    })
  }
}
module.exports = sp
