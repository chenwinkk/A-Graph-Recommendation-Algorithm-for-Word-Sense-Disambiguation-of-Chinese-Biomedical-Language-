const base = {
  url: 'http://127.0.0.1:3030'
}

export default base
